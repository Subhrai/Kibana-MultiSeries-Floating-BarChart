// dropdown control for filtering dashboards
import { VisTypesRegistryProvider } from 'ui/registry/vis_types';
import { VisSchemasProvider } from 'ui/vis/editors/default/schemas';
//import { TemplateVisTypeProvider } from 'ui/template_vis_type/template_vis_type';
import { VisFactoryProvider } from 'ui/vis/vis_factory';
import { CATEGORY } from 'ui/vis/vis_category';

VisTypesRegistryProvider.register(DropdownVisProvider);
require('plugins/multi-line/multiline.less');
require('plugins/multi-line/multilineController');
require('ui-select');
function DropdownVisProvider(Private) {
const VisFactory = Private(VisFactoryProvider);
const Schemas = Private(VisSchemasProvider);

return VisFactory.createAngularVisualization({
name: 'multiline',
type: 'multiline',
title: 'multiline Picker',
icon: 'fa-caret-square-o-down',
category: CATEGORY.OTHER,
description: 'In-dashboard dropdown filter widget',
visConfig: {
template: require('plugins/multi-line/multiline.html'),
defaults: {
addLegend: true,
isFacet: false,
addLevel: true,
addAxe: true,
addVertice: true,
addPolygon: true,
addLevelLabel: true,
addAxeLabel: true,
addLevelScale: 1,
addLabelScale: 0.9,
addLevelNumber: 5
}
},
editorConfig: {
optionsTemplate: require('plugins/multi-line/multilineOption.html'),
schemas: new Schemas([
{
group: 'metrics',
name: 'metric',
title: 'Y-Axis',
aggFilter: ['!geo_centroid', '!geo_bounds'],
min: 1,
defaults: [
{ schema: 'metric', type: 'count' }
]
},
{
group: 'buckets',
name: 'segment',
title: 'X-Axis',
min: 0,
max: 1,
aggFilter: ['!geohash_grid', '!filter']
},
{
group: 'buckets',
name: 'group',
title: 'Split Series',
min: 0,
max: 1,
aggFilter: ['!geohash_grid', '!filter']
}
])
},
responseHandler: 'none'
});
}

export default DropdownVisProvider;

