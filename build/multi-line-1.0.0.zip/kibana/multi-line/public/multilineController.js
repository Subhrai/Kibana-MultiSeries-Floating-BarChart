import d3 from 'd3';
import { AggResponseTabifyProvider } from 'ui/agg_response/tabify/tabify';
import { uiModules } from 'ui/modules';

const module = uiModules.get('kibana/multi-line', ['kibana']);

module.controller('multilineController', function ($scope, $element, $rootScope, Private) {
    const tabifyAggResponse = Private(AggResponseTabifyProvider);
  // console.log($scope.visData);
    // $scope.$watch('visData', function (resp) {
    //     console.log('we are inside function');         
    //   });
});
